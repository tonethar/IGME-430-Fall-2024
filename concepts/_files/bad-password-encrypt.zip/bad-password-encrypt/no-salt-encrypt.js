// npm i
// npm start
const crypto = require('crypto');
let badpassword = '1234';
let md5 = crypto.createHash('md5').update(badpassword).digest('hex');
console.log(`md5 = ${md5}`);

const sha1 = require('sha1');
let hash = sha1(badpassword);
console.log(`sha1 = ${hash}`); 
console.log('Now go ahead and google these hashes to see if they show up in a rainbow table!'); 